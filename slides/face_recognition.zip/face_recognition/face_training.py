import cv2
import os
import numpy as np

# Using LBPH(Local Binary Patterns Histograms) recognizer
recognizer = cv2.face.LBPHFaceRecognizer_create()
face_detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
path = "dataset/train"


# function to read the images in the dataset, convert them to grayscale values, return samples
def getImagesAndLabels(path):
    faceSamples = []
    ids = []

    labels = []
    for folder_name in os.listdir(path):
        labels.append(folder_name)
    label_ids = {label: id + 1 for id, label in enumerate(labels)}
    print(label_ids)

    for folder_name in os.listdir(path):
        for file_name in os.listdir(os.path.join(path, folder_name)):
            if file_name.endswith(".jpg"):
                img_path = os.path.join(path, folder_name, file_name)
                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                faces = face_detector.detectMultiScale(
                    img,
                    scaleFactor=1.2,  # how much the image size is reduced at each image scale-20% reduction
                    minNeighbors=5,  # how many neighbors each candidate rectangle should have to retain it
                    minSize=(
                        50,
                        50,
                    ),  # Minimum possible object size. Objects smaller than this size are ignored.
                )

                for x, y, w, h in faces:
                    faceSamples.append(img[y : y + h, x : x + w])
                    ids.append(label_ids[folder_name])

    return faceSamples, ids


def trainRecognizer(faces, ids):
    recognizer.train(faces, np.array(ids))
    # Create the 'trainer' folder if it doesn't exist
    if not os.path.exists("trainer"):
        os.makedirs("trainer")
    # Save the model into 'trainer/trainer.yml'
    recognizer.write("trainer/trainer.yml")


print("\n [INFO] Training faces. It will take a few seconds. Wait ...")
# Get face samples and their corresponding labels
faces, ids = getImagesAndLabels(path)
# Train the LBPH recognizer using the face samples and their corresponding labels
trainRecognizer(faces, ids)


# Print the number of unique faces trained
num_faces_trained = len(set(ids))
print("\n [INFO] {} faces trained.".format(num_faces_trained))


# Testing the model
def testRecognizer(frameGray, names):
    faces = face_detector.detectMultiScale(
        frameGray,  # The grayscale frame to detect
        scaleFactor=1.1,  # how much the image size is reduced at each image scale-10% reduction
        minNeighbors=5,  # how many neighbors each candidate rectangle should have to retain it
        minSize=(
            50,
            50,
        ),  # Minimum possible object size. Objects smaller than this size are ignored.
    )
    print(faces)
    for x, y, w, h in faces:
        # recognizer.predict() method takes the ROI as input and
        # returns the predicted label (id) and confidence score for the given face region.
        id, confidence = recognizer.predict(frameGray[y : y + h, x : x + w])
        print(id, names[id], confidence)


print("\n [INFO] Testing images in test folder \n")
test_path = "dataset/test"
names = ["none"]
for folder_name in os.listdir(path):
    names.append(folder_name)
names.append("Unknown")
for image_path in os.listdir(test_path):
    img = cv2.imread(os.path.join(test_path, image_path), cv2.IMREAD_GRAYSCALE)
    print("\n Test image name: ", image_path, "\n")
    testRecognizer(img, names)
